<?php

namespace App\Models;

use App\Traits\CustomFileTrait;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;

class Notification extends Model
{
    use CustomFileTrait,SoftDeletes;
    protected $table = 'notification';

    protected $fillable = ['type', 'product_id', 'quantity', 'seller_id', 'seen'];

    public function scopeSeen($query) {
        return $query->where('seen', 1);
    }

    public function seller () {
        return $this->belongsTo('App\Models\Seller','seller_id','id');
    }

    public function product () {
        return $this->belongsTo('App\Models\Product','product_id','id');
    }
}
