<div class="nav-wrapper">
    <ul role="tablist" id="tablist" class="nav nav-pills nav-tabs nav-fill">

        <li class="nav-item" >
            <a data-toggle="tab" data-id="1" role="tab" data-tabname="tab-general" href="#tab-general" class="nav-link active" aria-selected="true">
                <div>General</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" data-id="2" role="tab" data-tabname="tab-data" href="#tab-data" class="nav-link">
                <div>Data</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" data-id="4" role="tab" data-tabname="tab-links" href="#tab-links" class="nav-link">
                <div>Links</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" data-id="5" role="tab" data-tabname="tab-option" href="#tab-option" class="nav-link">
                <div>Option</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" data-id="3" role="tab" data-tabname="tab-data" href="#tab-attribute" class="nav-link">
                <div>Attribute</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" data-id="5" role="tab" data-tabname="tab-special" href="#tab-special" class="nav-link">
                <div>Special</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" data-id="6" role="tab" data-tabname="tab-image" href="#tab-image" class="nav-link">
                <div>image</div>
            </a>
        </li>
    </ul>
</div>
