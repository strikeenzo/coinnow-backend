<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Special;
use Illuminate\Http\Request;
use App\Traits\CustomFileTrait;
use App\Models\Seller;
use Illuminate\Support\Facades\Date;
use Validator;
use File;
use DB;
use Auth;
use Hash;
use Carbon\Carbon;

class SellerApiController extends Controller
{
   private $getUser;
   use CustomFileTrait;
   protected $path = '';

   public function __construct()
   {
      $this->path = public_path(config('constant.file_path.user'));
      $this->middleware(function ($request, $next) {
          $this->getUser = Auth::guard('seller')->user();
          return $next($request);
        });
    }

  public function getSellerDetails() {
       $specials = Special::select('quantity', 'product_id')->where('seller_id', $this->getUser->id)->with('product:id,image')->get();
       //$specials = Special::join('product', 'product.id', '=', 'special.product_id')->get();
       return  ['status' => 1,'data' => $this->getUser, 'specials' => $specials ];
  }

    //search products
  public function searchProducts( Request $request) {
        try {
            $keyword = $request->get('q', '');
            $records = Product::select('id','image', 'price', 'quantity','sort_order','status', 'sale', 'created_at', 'deleted_at')
                //->where('deleted_at', '<', new Carbon())
                ->where('seller_id', $this->getUser->id)
                ->with('productDescription:name,id,product_id','special:product_id,price,start_date,end_date')
                ->when(!empty($keyword) , function($q) use($keyword) {
                    $q->whereHas('productDescription',function($q) use($keyword){
                        $q->where('name','like',"%$keyword%");
                    });
                })
                //->orderBy('sort_order','ASC')
                ->get();

            return ['status'=> 1,'data'=>$records];
        } catch (\Exception $e) {
            return ['status'=> 0,'message'=>'Error'];
        }
   }

    public function something( Request $request) {
        try {
            $keyword = $request->get('q', '');
            $records = Product::select('id','image', 'price', 'quantity','sort_order','status', 'sale', 'created_at', 'deleted_at')
                //->where('deleted_at', '<', new Carbon())
                ->where('seller_id', 1)
                ->with('productDescription:name,id,product_id','special:product_id,price,start_date,end_date')
                ->when(!empty($keyword) , function($q) use($keyword) {
                    $q->whereHas('productDescription',function($q) use($keyword){
                        $q->where('name','like',"%$keyword%");
                    });
                })
                //->orderBy('sort_order','ASC')
                ->get();

            return ['status'=> 1,'data'=>$records];
        } catch (\Exception $e) {
            return ['status'=> 0,'message'=>'Error'];
        }
    }

   public function updateProfile(Request $request) {

     try {
        $validator = Validator::make($request->all(),[
                'firstname'          => 'required|regex:/^[\pL\s\-]+$/u',
                'telephone'     => 'required|max:11',
             ]
           );

           if ($validator->fails())
           {
             $message = $this->one_validation_message($validator);
               return  ['status' => 0 , 'message' => $message];
           }

           $update = Seller::where('id',$this->getUser->id)->update($request->all());
           $getNew = Seller::select('firstname','lastname','email', 'store_name','telephone')->findOrFail($this->getUser->id);
           return  ['status'=> 1,'message'=>'Profile updated successfully!','data' =>$getNew ];

     } catch (\Exception $e) {
       return  ['status'=> 0,'message'=>'Error' ];
     }

   }

   public function updateProduct(Request $request, $id) {


       $product = Product::whereId($id)->first();
       if (!empty($product)) {
           $product->price = $request->price;
           $product->save();
       }
       return  ['status'=> 1,'message'=>'Product updated successfully!' ];
   }

    public function listProductSale(Request $request, $id) {
        $product = Product::whereId($id)->first();
        if (!empty($product)) {
            $product->sale = 1;
            $product->save();
        }
        return  ['status'=> 1,'message'=>'Product updated successfully!' ];
    }

   public function changePassword(Request $request) {
     try {

       $validator = Validator::make($request->all(),[
               'current_password'     => 'required',
               'new_password'     => 'required',
            ]
          );
          if ($validator->fails())
          {
            $message = $this->one_validation_message($validator);
              return  ['status' => 0 , 'message' => $message];
          }

          $current_password = $this->getUser->password;
          if(Hash::check($request->current_password, $current_password))
          {
            $seller = Seller::find($this->getUser->id);
              $seller->password = Hash::make($request->new_password);
              $seller->save();
            return  ['status'=> 1,'message'=>'Password successfully changed' ];
          }
          else {
            return  ['status'=> 0,'message'=>'Current password wrong!' ];
          }
     } catch (\Exception $e) {
       return  ['status'=> 0,'message'=>'Error' ];
     }
   }

   public function one_validation_message($validator)
   {
      $validation_messages = $validator->getMessageBag()->toArray();
      $validation_messages1 = array_values($validation_messages);
         $new_validation_messages = [];
         for ($i = 0; $i < count($validation_messages1); $i++)
         {
             $inside_element = count($validation_messages1[$i]);
              for ($j=0; $j < $inside_element; $j++)
              {
                array_push($new_validation_messages,$validation_messages1[$i]);
              }
         }
      return implode(' ',$new_validation_messages[0]);
   }

}
